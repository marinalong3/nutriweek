require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');
const subscriptionRoutes = require('./routes/subscription');
const mealRoutes = require('./routes/meal');
const shoppingRoutes = require('./routes/shopping');
const nutritionRoutes = require('./routes/nutrition');
const adminRoutes = require('./routes/admin');
const webhookRoutes = require('./routes/webhooks');

const app = express();

// Webhooks precisam do raw body
app.use('/api/webhooks', express.raw({ type: 'application/json' }), webhookRoutes);

app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL, credentials: true }));
app.use(express.json({ limit: '10mb' }));

// Rate limiting global
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 100 });
app.use('/api/', limiter);

// Rate limiting mais restrito para IA
const aiLimiter = rateLimit({ windowMs: 60 * 60 * 1000, max: 20 });
app.use('/api/meal/generate', aiLimiter);

// Rotas
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/subscription', subscriptionRoutes);
app.use('/api/meal', mealRoutes);
app.use('/api/shopping', shoppingRoutes);
app.use('/api/nutrition', nutritionRoutes);
app.use('/api/admin', adminRoutes);

app.get('/api/health', (req, res) => res.json({ status: 'ok', app: 'NutriWeek' }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🥗 NutriWeek server rodando na porta ${PORT}`));
